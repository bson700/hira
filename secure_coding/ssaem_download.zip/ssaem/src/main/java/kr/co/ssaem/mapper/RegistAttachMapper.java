package kr.co.ssaem.mapper;

import java.util.List;

import kr.co.ssaem.domain.RegistAttachVO;

public interface RegistAttachMapper {
    public void insert(RegistAttachVO rgvo);

    public void delete(String uuid);

    public List<RegistAttachVO> findByRgno(Long rgno);

    public void deleteAllByRgno(Long rgno);
}
