package kr.co.ssaem.mapper;

import kr.co.ssaem.domain.AnswerVO;

public interface AnswerMapper {

    public Integer insertSelectKey(AnswerVO asvo);

    public AnswerVO read(AnswerVO asvo);

    public int delete(AnswerVO asvo);

    public int update(AnswerVO asvo);

    public Long getAsno(Long rgno);
}
