package kr.co.ssaem.service;

import java.util.List;

import kr.co.ssaem.domain.Criteria;
import kr.co.ssaem.domain.ReplyPageDTO;
import kr.co.ssaem.domain.ReplyVO;

public interface ReplyService {

    public int register(ReplyVO vo);

    public ReplyVO get(Long rno);

    public int modify(ReplyVO vo);

    public int remove(Long rno);

    public int removeAllByBno(Long bno);

    public List<ReplyVO> getList(Criteria cri, Long bno);

    public ReplyPageDTO getListPage(Criteria cri, Long bno);

}
