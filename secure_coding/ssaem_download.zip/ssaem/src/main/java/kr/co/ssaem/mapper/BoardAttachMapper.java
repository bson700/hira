package kr.co.ssaem.mapper;

import java.util.List;

import kr.co.ssaem.domain.BoardAttachVO;

public interface BoardAttachMapper {
    public void insert(BoardAttachVO vo);

    public void delete(String uuid);

    public List<BoardAttachVO> findByBno(Long bno);

    public void deleteAllByBno(Long bno);
}
