package kr.or.hira.db;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import lombok.extern.log4j.Log4j2;

@ExtendWith(SpringExtension.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j2
public class DBTests {

	@Autowired
	DataSource ds;

	@Disabled
	@Test
	public void testConnect() {
		// try with resource 방식
		try(Connection con = ds.getConnection()) {
			log.info(con);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void test1() {
		log.trace("test1---t-------");
		log.debug("test1---d-------");
		log.info("test1---i-------");
		log.error("test1---e-------");
		log.warn("test1---w-------");
		log.fatal("test1---f-------");
	}
}
