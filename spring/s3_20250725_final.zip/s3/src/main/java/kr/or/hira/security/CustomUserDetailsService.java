package kr.or.hira.security;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class CustomUserDetailsService implements UserDetailsService {

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		log.info("------------------------------------------");
		log.info("------------------------------------------");
		log.info("loadUserByUsername: " + username);
		log.info("------------------------------------------");
		log.info("------------------------------------------");
		
		return null;
	}

}
