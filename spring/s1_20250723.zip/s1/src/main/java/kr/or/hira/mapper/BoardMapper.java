package kr.or.hira.mapper;

import java.util.List;

//import org.apache.ibatis.annotations.Param;

import kr.or.hira.dto.BoardDTO;
import kr.or.hira.dto.PageRequestDTO;

public interface BoardMapper {

	//List<BoardDTO> list(int skip);

	// 1) 파라미터 만드는 방법, 2) DTO 만드는 방법
	// 2)번이 더 좋은 방법이다.
//	List<BoardDTO> list(@Param("skip") int skip, @Param("skip") int limit);
	
	//List<BoardDTO> list(PageRequestDTO dto);
	
	List<BoardDTO> list(PageRequestDTO requestDTO);
	
	int insert(BoardDTO boardDTO);
	
	BoardDTO selectOne(Long bno);
	
	int remove(Long bno);
	
	int update(BoardDTO dto);

}
