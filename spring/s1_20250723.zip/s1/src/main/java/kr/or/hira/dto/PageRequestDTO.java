package kr.or.hira.dto;

public class PageRequestDTO {

	private int page = 1; // 페이지 번호
	private int size = 10;// limit 사이즈
	private String types; // T, TC, TCW, CW ... -> [T, C, W]
	private String keyword;

	public String[] getArr() {
		if (types == null) {
			return new String[] {};
		}
		return types.split("");
	}

	public int getPage() {
		return this.page;
	}

	public String getTypes() {
		return types;
	}

	public void setTypes(String types) {
		this.types = types;
	}

	public String getKeyword() {
		return keyword;
		// 자바에서 트림쓰면 성능 떨어짐

	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public void setPage(int page) {
		this.page = page <= 0 ? 1 : page;
	}

	public void setSize(int size) {
		this.size = size <= 10 ? 10 : size > 100 ? 50 : size;
	}

	// offset = (page - 1) * size
	public int getOffset() {
		return (page - 1) * size;
	}

	public int getLimit() {
		return this.size;
	}
}
