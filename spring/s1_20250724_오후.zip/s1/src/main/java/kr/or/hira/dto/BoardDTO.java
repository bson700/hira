package kr.or.hira.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * CREATE TABLE tbl_board (
    bno INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(500) NOT NULL,
    content VARCHAR(2000) NOT NULL,
    writer VARCHAR(50) NOT NULL,
    regdate timestamp default NOW() ,
    updatedate timestamp default NOW(),
    delflag BOOLEAN DEFAULT FALSE
);
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BoardDTO {
	private Long bno;
	private String title;
	private String content;
	private String Writer;
	private LocalDateTime regDate;
	private LocalDateTime updateDate;
	private boolean delFlag;

}
