package kr.or.hira.db;

import java.sql.Connection;

import javax.sql.DataSource;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import kr.or.hira.dto.BoardDTO;
import kr.or.hira.dto.PageRequestDTO;
import kr.or.hira.mapper.BoardMapper;
import kr.or.hira.mapper.TimeMapper;
import lombok.extern.log4j.Log4j2;

@ExtendWith(SpringExtension.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j2
public class DBTests {

	@Autowired
	private DataSource ds;

	@Autowired
	private TimeMapper timeMapper;

	@Autowired
	private BoardMapper boardMapper;
	
	@Test
	public void test4() {
		log.info(timeMapper); // INFO org.apache.ibatis.binding.MapperProxy@ab20d7c

		//진짜 클래스의 이름
		log.info(timeMapper.getClass().getName()); // INFO jdk.proxy2.$Proxy33
		
		// instanceof 연산자로 if 체크하면 안된다.
		// timeMapper.getClass().getName() 를 사용해야 한다.
	}
	
	@Test
	public void testSelectOne() {
		Long bno = 2L;
		// 아래처럼 없는 번호를 조회하면 널이라고 뜨고 예외는 발생하지 않는다.
		// 따라서 계속 널인치 체크해주거나, 옵셔널 사용해야 한다.
		//Long bno = 200000L;
		BoardDTO board = boardMapper.selectOne(bno);
		log.info("board: " + board);
	}
	
	@Test
	public void testInsert2() {
	BoardDTO boardDTO = BoardDTO.builder()
	.title("title")
	.content("content")
	.Writer("user00")
	.build();
	

	int insertCount = boardMapper.insert(boardDTO);
	log.info("-------------------");
	log.info("isnertCount: " + insertCount);
	log.info("=================================");
	log.info("BNO: " +boardDTO.getBno());
	}
	
//	@Test
//	public void testDTO() {
//		PageRequestDTO requestDTO = new PageRequestDTO();
//		requestDTO.setPage(11);
//		
//	}
	
	@Test
	public void testList() {

		PageRequestDTO requestDTO = new PageRequestDTO();
		requestDTO.setTypes("TCW");
		requestDTO.setKeyword("44");
		
		//requestDTO.setPage(1);
		//requestDTO.setSize(10);

		boardMapper.list(requestDTO).stream().forEach(log::info);
	}

	@Test
	public void testNow() {
		log.info(timeMapper.getTime());
	}

	@Disabled
	@Test
	public void testConnect() {
		// try with resource 방식
		try (Connection con = ds.getConnection()) {
			log.info(con);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void test1() {
		log.trace("test1---t-------");
		log.debug("test1---d-------");
		log.info("test1---i-------");
		log.error("test1---e-------");
		log.warn("test1---w-------");
		log.fatal("test1---f-------");
	}
}
