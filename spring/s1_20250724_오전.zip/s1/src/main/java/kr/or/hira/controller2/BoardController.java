package kr.or.hira.controller2;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.or.hira.dto.BoardDTO;
import kr.or.hira.dto.PageRequestDTO;
import kr.or.hira.service.BoardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Controller
@RequestMapping("/board")
@Log4j2
@RequiredArgsConstructor
public class BoardController {
	
	private final BoardService boardService; // 기법: 생정자 주입
	
	//리스트를 만드는 것이 좋음
	//대부분의 시작이 리스트이기 때문
	@GetMapping("list")
	public void list(PageRequestDTO requestDTO, Model model) {
		
		log.info("list");
		log.info(requestDTO);
		
		model.addAttribute("result", boardService.list(requestDTO));
	}
	
	@GetMapping("register")
	public void register( ) { 
		log.info("register");
	}
	
	//RedirectAttributes rttr로 세션정보 받아서 값 비교해서 모달창 띄움
	@PostMapping("register")
	public String registerPOST(BoardDTO dto, RedirectAttributes rttr) {
		log.info("register post");
		log.info(dto);
		
		//한 번만 값 전달할 때 사용
		rttr.addFlashAttribute("bno", 123456);
		
		return "redirect:/board/list";
	}
	
	@GetMapping("read/{bno}")
	public String readOne(@PathVariable("bno")Long bno) {
		
		log.info("read bno:" + bno);
		
		return "/board/read";
	}
	
}
