package kr.or.hira.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.or.hira.dto.BoardDTO;
import kr.or.hira.dto.PageRequestDTO;
import kr.or.hira.dto.PageResponseDTO;
import kr.or.hira.mapper.BoardMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@RequiredArgsConstructor
@Log4j2
@Transactional
public class BoardService {

	private final BoardMapper boardMapper;

	// select 는 항상 readonly
//	@Transactional(readOnly = true)
//	public void list(PageRequestDTO requestDTO) {
//		boardMapper.list(requestDTO);
//	}

	@Transactional(readOnly = true)
	public PageResponseDTO<BoardDTO> list(PageRequestDTO requestDTO) {
		// count를 한번 더 날려야 해서 비효율적인 코드임
		List<BoardDTO> dtoList = boardMapper.list(requestDTO);
		int count = boardMapper.count(requestDTO);

		return new PageResponseDTO<BoardDTO>(dtoList, requestDTO, count);
	}

}
