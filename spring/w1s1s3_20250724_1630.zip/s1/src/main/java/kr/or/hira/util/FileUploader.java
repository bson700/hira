package kr.or.hira.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.log4j.Log4j2;
import net.coobird.thumbnailator.Thumbnails;

@Log4j2
public class FileUploader {

	public static List<String> upload(MultipartFile[] files) throws RuntimeException {

		List<String> uploadNames = new ArrayList<>();

		if (files == null || files.length == 0) {
			return uploadNames;
		}

		String uploadPath = "C:\\202507\\upload";

		log.info("---------------uploadPath-----------------");
		log.info(uploadPath);

		for (MultipartFile file : files) {

			if (file.isEmpty()) {
				continue;
			}

			String fileName = file.getOriginalFilename();

			String uploadName = UUID.randomUUID().toString() + "_" + fileName;

			File targetFile = new File(uploadPath, uploadName);

			try (InputStream fin = file.getInputStream(); OutputStream fos = new FileOutputStream(targetFile);) {

				log.info(targetFile.getAbsolutePath());

				FileCopyUtils.copy(fin, fos);

				uploadNames.add(uploadName);

			} catch (Exception e) {
				log.error(e.getMessage());
				throw new RuntimeException(e.getMessage());
			}

			if (file.getContentType().startsWith("image")) {

				try {
					Thumbnails.of(targetFile).size(200, 200).toFile(new File(uploadPath, "s_" + uploadName));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		} // end for

		return uploadNames;

	}

}
