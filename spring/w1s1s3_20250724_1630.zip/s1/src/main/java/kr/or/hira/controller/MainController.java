package kr.or.hira.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import kr.or.hira.util.FileUploader;
import lombok.extern.log4j.Log4j2;

@Controller
@Log4j2
public class MainController {

	@PostMapping("upload")
	public String upload(@RequestParam("files") MultipartFile[] files) {
		List<String> uploadNames = FileUploader.upload(files);

		log.info(uploadNames);

		return "index";

	}
}
