package kr.or.hira.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.or.hira.dto.PageRequestDTO;
import kr.or.hira.dto.PageResponseDTO;
import kr.or.hira.dto.ReplyDTO;
import kr.or.hira.mapper.ReplyMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@RequiredArgsConstructor
@Transactional
@Log4j2
public class ReplyService {

	private final ReplyMapper replyMapper;

	public ReplyDTO add(ReplyDTO replyDTO) {

		replyMapper.insert(replyDTO);

		return replyDTO;

	}

	public ReplyDTO getOne(Long rno) {

		return replyMapper.read(rno);

	}

	public void modify(ReplyDTO replyDTO) {
		int count = replyMapper.update(replyDTO);

	}

	public void remove(Long rno) {

		int count = replyMapper.delete(rno);

	}

	public PageResponseDTO<ReplyDTO> listOfBoard(Long bno, PageRequestDTO dto) {

		int skip = dto.getOffset();
		int size = dto.getLimit();

		List<ReplyDTO> replyDTOList = replyMapper.listOfBoard(bno, skip, size);

		int count = replyMapper.countOfBoard(bno);

		return new PageResponseDTO<ReplyDTO>(replyDTOList, dto, count);

	}

}
