package kr.or.hira.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.or.hira.dto.BoardDTO;
import kr.or.hira.dto.PageRequestDTO;
import kr.or.hira.dto.PageResponseDTO;
import kr.or.hira.mapper.BoardMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@RequiredArgsConstructor
@Log4j2
@Transactional
public class BoardService {

	private final BoardMapper boardMapper;

	@Transactional(readOnly = true)
	public PageResponseDTO<BoardDTO> list(PageRequestDTO requestDTO) {
		
		List<BoardDTO> dtoList = boardMapper.list(requestDTO);
		int count = boardMapper.count(requestDTO);
		
		return new PageResponseDTO<BoardDTO>(dtoList, requestDTO, count);
	}
	
	@Transactional(readOnly = true)
	public BoardDTO getOne(Long bno) {
		
		return boardMapper.selectOne(bno);
	}
	
}









