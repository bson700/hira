package kr.or.hira.mapper;

import java.util.List;

import kr.or.hira.dto.BoardDTO;
import kr.or.hira.dto.PageRequestDTO;

public interface BoardMapper {

	List<BoardDTO> list(PageRequestDTO requestDTO);
}
