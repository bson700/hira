package kr.or.hira.mapper;

public interface TimeMapper {
	
	String getTime();
	
	
}
