package kr.or.hira.dto;

import lombok.ToString;

@ToString
public class PageRequestDTO {

	private int page = 1;
	private int size = 10;
	private String types; // T, TC, TCW, CW -> [T,C,W]
	private String keyword;

	public String[] getArr() {
		if (types == null) {
			return new String[] {};
		}
		return types.split("");
	}

	public String getTypes() {
		return types;
	}

	public void setTypes(String types) {
		this.types = types;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public void setPage(int page) {

		this.page = page <= 0 ? 1 : page;
	}

	public void setSize(int size) {

		this.size = size <= 10 ? 10 : size > 100 ? 50 : size;
	}

	public int getOffset() {

		return (page - 1) * size;
	}

	public int getLimit() {

		return this.size;
	}

	public int getPage() {
		return page;
	}

}
