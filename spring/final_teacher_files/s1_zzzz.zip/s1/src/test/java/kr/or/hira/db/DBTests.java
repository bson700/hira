package kr.or.hira.db;

import javax.sql.DataSource;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import kr.or.hira.dto.BoardDTO;
import kr.or.hira.dto.PageRequestDTO;
import kr.or.hira.dto.PageResponseDTO;
import kr.or.hira.mapper.BoardMapper;
import kr.or.hira.mapper.TimeMapper;
import lombok.extern.log4j.Log4j2;

@ExtendWith(SpringExtension.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml") // 메모리 상에서 로딩
@Log4j2
public class DBTests {
	
	@Autowired
	private DataSource ds;
	
	@Autowired
	private TimeMapper timeMapper;
	
	@Autowired
	private BoardMapper BoardMapper;
	
	@Test
	public void test4() {
		log.info(timeMapper.getClass().getClass());
	}
	
	@Test
	public void testnow() {
		log.info(timeMapper.getTime());
	}
	
	@Test
	public void testList() {
		
		PageRequestDTO requestDTO = new PageRequestDTO();
		requestDTO.setTypes("TCW");
		requestDTO.setKeyword("44");
		
//		requestDTO.setPage(2);
//		requestDTO.setSize(10);
		
		BoardMapper.list(requestDTO).stream().forEach(log::info);
	}
	
	@Test
	public void testDTO() {
		PageRequestDTO requestDTO = new PageRequestDTO();
		requestDTO.setPage(11);
		PageResponseDTO<BoardDTO> res = new PageResponseDTO<>(null, requestDTO, 250);
		
		log.info(res);	
	}
	
	@Test
	public void testInsert2() {
		BoardDTO boardDTO = BoardDTO.builder().title("title").content("content").writer("user00").build();
		int insertCount = BoardMapper.insert(boardDTO);
		log.info("-------------------");
		log.info("isnertCount: " + insertCount);
		log.info("=================================");
		log.info("BNO: " + boardDTO.getBno());
	}
	
	
	@Test
	public void testSelectOne() {
		Long bno = 50000L;
		BoardDTO board = BoardMapper.selectOne(bno);
		log.info("board: " + board);
	}
	
	
	@Autowired
	private DataSource dataSource;

	@Test
	public void testConnection() {
		log.info("----------------");
		log.info(dataSource);
		log.info("----------------");
	}

}